module.exports = {
    HOST: 'localhost',
    USERNAME: 'root',
    PASSWORD: '',
    DATABASE: 'gudang_barokah',
    dialect: 'mysql'
}